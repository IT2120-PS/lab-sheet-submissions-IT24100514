setwd("C:\\Users\\it24100514\\Desktop\\LAB4")
getwd()

data <- read.table("DATA 4.txt",header=TRUE,sep= " ")
fix(data)

attach(data)

boxplot(X1,main="Box plot for Team attendance",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)


hist(X1,ylab="Frequency",xlab="Team Attendance",main="Histogram for team attendance")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for team salary")
hist(X3,ylab="Frequency",xlab="Years",main="Histogram for Years")


stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)


##1
branch_data <- read.csv("Exercise.txt", header = TRUE)

##2
str(branch_data)

##3
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        outline = TRUE,
        outpch=8,
        horizontal = TRUE)

##4
summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

##5
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z < lb | z > ub]), collapse = ", ")))
}

get.outliers(branch_data$Years_X3)
