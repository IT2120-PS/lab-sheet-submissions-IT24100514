setwd("C:\\Users\\Owner\\Desktop\\IT24100514_LAB_6")
getwd()

##Question 01 

#part 01
##Binomial distribution
##Here, Random variable X has Binomial distribution with n=44 and P=0.92


##Part 02 
dbinom(40,44,0.92)

#part 03
pbinom(35,44,0.92,lower.tail = TRUE )

#par04
1 - pbinom(37,44,0.92,lower.tail = TRUE )
pbinom(37,44,0.92,lower.tail = FALSE )

#Part05
pbinom(42,44,0.92,lower.tail = TRUE ) - pbinom(39,44,0.92,lower.tail = TRUE )


#Question 02
#part01

#Number of babies born in a hospital on a given day

#part02
#Poisson Distribution
#Here random variable X has poisson distribution with lambda = 5

#part03
dpois(6,5)

#part04
ppois(6,5, lower.tail = FALSE)


#Exercise 

#01

#Part01
#Binomial distribution

#part02

pbinom(46,50,0.85,lower.tail = FALSE )

1 - pbinom(46,50,0.85, lower.tail = TRUE)

#02

#par01

#X = number of calls received per hour

#Part02

#Poisson distribution with lambda = 12

#Part03

dpois(15,12)






